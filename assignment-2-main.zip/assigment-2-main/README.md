# rca

    .
    ├── ci
    ├── rtl             
        ├── rca_top.v  # your rtl design # io: 
        ├              input  [31:0] A_i,
        ├              input  [31:0] B_i,
        ├              input         C_i,
        ├              input         Sel_i,
        ├              output [31:0] Sum_o,
        ├              output        C_o,
        ├              output        Overflow_o,
        ├── tb_rca.v   # your testbench

#!/bin/bash

file1="$1"
echo $file1
file2="$2"
echo $file2
error_flag=false
line_number=1

if [[ ! -f "$file1" || ! -f "$file2" ]]; then
    printf "\n\033[31merror: file paths are wrong.\033[0m\n"
    exit 1
fi

while IFS= read -r line1 && IFS= read -r line2 <&3; do
    if [[ "$line1" != "$line2" ]]; then
        error_flag=true
        echo "error at:$line_number"
        echo "Reference: $line1"
        echo "Test     : $line2"
        echo "-------------------"
    fi
    line_number=$((line_number + 1))        
done < "$file1" 3< "$file2"

if [[ "$error_flag" == true ]]; then
    printf "\033[31merror. Test is not verified.\033[0m\n"
    exit 1
else
    printf "\033[32mSucces\033[0m\n"
    exit 0
fi
